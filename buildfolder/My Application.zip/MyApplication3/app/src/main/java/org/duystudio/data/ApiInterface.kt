package org.duystudio.data

import retrofit2.http.GET
import retrofit2.http.QueryMap

interface ApiInterface {

    @GET("countries")
    suspend fun getCountries(@QueryMap params: Map<String, String>)

    @GET("states")
    suspend fun getStateSupportInCountries(@QueryMap params: Map<String, String>)

    @GET("cities")
    suspend fun getCitySupportInState(@QueryMap params: Map<String, String>)


}