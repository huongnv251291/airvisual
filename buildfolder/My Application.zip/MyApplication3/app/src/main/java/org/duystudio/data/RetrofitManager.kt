package org.duystudio.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

class RetrofitManager {
    var apiInterface: ApiInterface? = null
        get() {
            val interceptor = HttpLoggingInterceptor()
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY)
            val builder: OkHttpClient.Builder = OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .retryOnConnectionFailure(true)
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
            val client: OkHttpClient = builder.build()
            if (field == null) {
                val retrofit: Retrofit = Retrofit.Builder()
                    .addConverterFactory(GsonConverterFactory.create())
                    .addConverterFactory(ScalarsConverterFactory.create())
                    .baseUrl("http://api.airvisual.com/v2/")
//                    .baseUrl("https://api.jsonbin.io/")
                    .client(client)
                    .build()
                field = retrofit.create<ApiInterface>(ApiInterface::class.java)
            }
            return field
        }
    companion object {
        var instance: RetrofitManager? = null
            get() {
                if (field == null) {
                    synchronized(RetrofitManager::class.java) {
                        if (null == field) {
                            field = RetrofitManager()
                        }
                    }
                }
                return field
            }
            private set
    }
}